export const DB_URL = "mongodb://127.0.0.1:27017/seatmanagement";

// export const DB_URL = "mongodb+srv://saurabhdadhe1997:s6yFUF3i3oi5uCt7@seatmanage.jsjcqlu.mongodb.net/?retryWrites=true&w=majority&appName=seatmanage";

