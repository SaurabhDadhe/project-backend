import express from "express";
// import { Seat } from "../models/SeatModel";
import mongoose from 'mongoose';

import { User } from "../models/UserModel.js";


const testR = express.Router();

testR.get('/:id', async (req, res) => {
    const uid = parseInt(req.params.id);
    try {
        const result = await User.aggregate([
            {
                $match: { id: uid } // Match the user ID
            },
            {
                $lookup: {
                    from: 'seats', // Name of the Seat collection
                    localField: 'id', // Field from the User collection
                    foreignField: 'userid', // Field from the Seat collection
                    as: 'booked_info' // Alias for the joined data
                }
            },
            {
                $unwind: '$booked_info' // Unwind the array to merge seat data
            }
        ]);

        if (result.length === 0) {
            return res.status(404).send('User not found');
        }
        console.log(result[0].booked_info.seatno);
        res.json(result);
    } catch (error) {
        console.error('Error fetching user with seat information:', error);
        res.status(500).send('Server Error');
    }
});

export default testR;
